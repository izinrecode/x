# TempMail.LOL Website

This repository exists just so viewers can see the source code.

You may NOT copy this site to use as your own.

Copyright (C) Alexander Epolite 2022.  All rights reserved.
