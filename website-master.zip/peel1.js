
//https://www.detectadblock.com/

var e=document.createElement('div');
e.id='cDdEszJAIqie';
e.style.display='none';
document.body.appendChild(e);
