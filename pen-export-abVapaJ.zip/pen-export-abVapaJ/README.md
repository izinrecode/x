# Upload.js - JS Upload Library

A Pen created on CodePen.io. Original URL: [https://codepen.io/upload-js/pen/abVapaJ](https://codepen.io/upload-js/pen/abVapaJ).

Uploading files with Upload.js — the file upload library with integrated cloud storage. Developed by Upload.io.